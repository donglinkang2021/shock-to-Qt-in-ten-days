#include "addfriendwidget.h"
#include "ui_addfriendwidget.h"

AddFriendWidget::AddFriendWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AddFriendWidget)
{
    ui->setupUi(this);
    this->setWindowFlags(Qt::FramelessWindowHint); //无窗口边框
}

AddFriendWidget::~AddFriendWidget()
{
    delete ui;
}

void AddFriendWidget::on_minimizeButton_clicked()
{
    this->showMinimized();
}



void AddFriendWidget::on_closeButton_clicked()
{
    this->close();
}

void AddFriendWidget::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton)
    {
        m_dragStartPosition = event->globalPos() - frameGeometry().topLeft();
        event->accept();
    }
}

void AddFriendWidget::mouseMoveEvent(QMouseEvent *event)
{
    if (event->buttons() & Qt::LeftButton)
    {
        QPoint newPos = event->globalPos() - m_dragStartPosition;
        move(newPos);
        event->accept();
    }
}

void AddFriendWidget::on_button_addFriend_clicked()
{
    // 获取朋友用户名
}

void AddFriendWidget::on_button_search_clicked()
{
    // 搜索朋友是否存在
}
