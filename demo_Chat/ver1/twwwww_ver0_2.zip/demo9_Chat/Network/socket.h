#ifndef SOCKET_H
#define SOCKET_H

#include <QWidget>
#include <QTcpSocket>
#include <QMessageBox>
#include <QFileDialog>
#include <QStandardPaths>
#include <QDebug>

#include <QJsonObject>
#include <QJsonDocument>
#include <QJsonValue>
#include <QJsonArray>

class Socket : public QWidget
{
    Q_OBJECT
public:
    explicit Socket(
        QTcpSocket *s,
        QWidget *parent = nullptr
    );

    static Socket* instance; // 全局调用
    static QString username; // 当前用户

    // 发送
    void send_message(QString str);
    void send_attachment();

    // 数据库操作
    void sendRegister(QString username, QString password);
    void sendLogin(QString username, QString password);
    void sendAddFriend(QString username, QString friendname);
    void sendCreateGroup(QString username, QString groupname);
    void sendAddGroup(QString username, QString groupname);

    void sendSearchGroup(QString username);
    void sendSearchFriend(QString username);

    void sendMessage(QString sender, QString type,
                     QString receiver, QString msg); // type区分发送给群聊或者用户（或者服务器）
    void sendUserInfoChange(QString username,QString nickname = "",
                            QString headFile= "", QString birthday = "",
                            QString region = "", QString age = "",
                            QString sex = "");

signals:
    void newMessage(QString);

    void RegisterOK(bool isSuc);// 注册ok信号
    void LoginOK(bool isSuc); //登录进入
    void AddFriendOK(bool isSuc); // 加好友
    void CreateGroupOK(bool isSuc); // 建群成功
    void AddGroupOK(bool isSuc); // 加群ok
    void ChangeInfoOK(bool isSuc); // 改变信息
    void SearchFriendOK(bool isSuc, QList<QString> friendList); // 查找朋友
    void SearchGroupOK(bool isSuc, QList<QString> groupList); // 查找群聊
    void P2PMessageOK(bool isSuc);


private slots:
    // 读取
    void readSocket();
    void discardSocket();

private:
    QTcpSocket *socket;

    // 发送
    void sendSocket(QString message, QString fileType);

};

#endif // SOCKET_H
