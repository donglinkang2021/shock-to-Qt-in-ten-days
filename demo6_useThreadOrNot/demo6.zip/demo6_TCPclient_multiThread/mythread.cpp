#include "mythread.h"

myThread::myThread(QObject *parent) : QObject(parent)
{

}
