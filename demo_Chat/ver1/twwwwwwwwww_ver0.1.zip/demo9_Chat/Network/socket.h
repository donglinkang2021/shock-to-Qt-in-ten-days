#ifndef SOCKET_H
#define SOCKET_H

#include <QWidget>
#include <QTcpSocket>
#include <QMessageBox>
#include <QFileDialog>
#include <QStandardPaths>

class Socket : public QWidget
{
    Q_OBJECT
public:
    explicit Socket(
        QTcpSocket *s,
        QWidget *parent = nullptr
    );

    // 发送
    void send_message(QString str);
    void send_attachment();

signals:
    void newMessage(QString);

private slots:
    // 读取
    void readSocket();
    void discardSocket();



private:
    QTcpSocket *socket;

};

#endif // SOCKET_H
