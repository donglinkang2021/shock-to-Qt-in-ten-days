#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QMouseEvent>
#include <QSqlDatabase>
#include <QDebug>
#include <QSqlError>
#include <QMessageBox>
#include <QSqlQuery>
#include <QSqlTableModel>

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();
    void initDatabase();

    void create_Table_User();
    void create_Table_Friendship();
    void create_Table_Friendmsg();
    void create_Table_Groupinfo();
    void create_Table_Groupship();
    void create_Table_Groupmsg();

    void on_button_query_clicked();


private slots:

    void on_button_signup_clicked();

    void on_comboBox_tables_currentTextChanged(const QString &arg1);

    void on_button_login_clicked();

    void on_button_create_group_clicked();

    void on_button_query_group_clicked();

    void on_button_add_group_clicked();

    void on_button_send_group_clicked();

    void on_button_query_group_member_clicked();

    void on_button_query_group_list_clicked();

    void on_button_query_friend_clicked();

    void on_button_add_friend_clicked();

    void on_button_send_friend_clicked();

    void on_button_query_friend_list_clicked();

    void on_button_alter_nickname_clicked();

    void on_button_alter_profile_clicked();

private:
    Ui::Widget *ui;
    QSqlDatabase db;
    QSqlTableModel *model; // 总模型
    QSqlQueryModel *queryModel; //临时查询模型
};
#endif // WIDGET_H
