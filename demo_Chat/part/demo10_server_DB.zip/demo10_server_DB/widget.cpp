#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    initDatabase();
}

Widget::~Widget()
{
    if (db.open()){
        db.close();
    }
    if (model){
        delete model;
    }
    if (queryModel){
        delete queryModel;
    }
    delete ui;
}

void Widget::initDatabase(){
    //连接数据库 加载QSQLITE
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("mydatabase.db");

    if (db.open()) {// 在这行代码之后才打开数据库
        QMessageBox::information(
            this, "连接提示", "成功连接数据库"
        );

        if (!db.tables().contains("User")){
            create_Table_User();
        }
        if (!db.tables().contains("Friendship")){
            create_Table_Friendship();
        }
        if (!db.tables().contains("Friendmsg")){
            create_Table_Friendmsg();
        }
        if (!db.tables().contains("Groupinfo")){
            create_Table_Groupinfo();
        }
        if (!db.tables().contains("Groupship")){
            create_Table_Groupship();
        }
        if (!db.tables().contains("Groupmsg")){
            create_Table_Groupmsg();
        }

        model = new QSqlTableModel;
        queryModel = new QSqlQueryModel; //之后用
        model->setTable("User");
        ui->tableView->setModel(model);

        // 刷新初始的数据库界面
        model->select();
    } else {
        QMessageBox::information(
            this, "连接提示", "连接失败"
        );
    }


}


void Widget::create_Table_User(){
    // 创建User表
    QSqlQuery sql_query;
    QString create_sql = "CREATE TABLE IF NOT EXISTS User (\
                              Username VARCHAR(20) PRIMARY KEY,\
                              Password VARCHAR(20) NOT NULL,\
                              Nickname VARCHAR(20),\
                              Profile_picture VARCHAR(100),\
                              Personal_signature VARCHAR(100),\
                              Sex VARCHAR(20),\
                              Age INTEGER,\
                              Birthday VARCHAR(20),\
                              Region VARCHAR(20)\
                              );";
    sql_query.prepare(create_sql);
    if(sql_query.exec()){
        qDebug() << "成功建User表！";
    }else{
        qDebug() << "Error: 创建User表失败" << sql_query.lastError();
    }
}

void Widget::create_Table_Friendship(){
    // 创建Friendship表
    QSqlQuery sql_query;
    QString create_sql = "CREATE TABLE IF NOT EXISTS Friendship (\
                              Myname VARCHAR(20) ,\
                              Friendname VARCHAR(20) ,\
                              PRIMARY KEY(Myname,Friendname),\
                              FOREIGN KEY (Myname) REFERENCES User(Username),\
                              FOREIGN KEY (Friendname) REFERENCES User(Username)\
                              );";
    sql_query.prepare(create_sql);
    if(sql_query.exec()){
        qDebug() << "成功建Friendship表！";
    }else{
        qDebug() << "Error: 创建Friendship表失败" << sql_query.lastError();
    }
}

void Widget::create_Table_Friendmsg(){
    // 创建Friendmsg表
    QSqlQuery sql_query;
    QString create_sql = "CREATE TABLE IF NOT EXISTS Friendmsg (\
                              Sender VARCHAR(20),\
                              Receiver VARCHAR(20),\
                              Msg VARCHAR(1024),\
                              DT datetime NOT NULL,\
                              FOREIGN KEY (Sender) REFERENCES User(Username),\
                              FOREIGN KEY (Receiver) REFERENCES User(Username)\
                              );";
    sql_query.prepare(create_sql);
    if(sql_query.exec()){
        qDebug() << "成功建Friendmsg表！";
    }else{
        qDebug() << "Error: 创建Friendmsg表失败" << sql_query.lastError();
    }
}

void Widget::create_Table_Groupinfo(){
    // 创建Groupinfo表
    QSqlQuery sql_query;
    QString create_sql = "CREATE TABLE IF NOT EXISTS Groupinfo (\
                              Groupname VARCHAR(20) PRIMARY KEY,\
                              Group_profile VARCHAR(100)\
                              );";
    sql_query.prepare(create_sql);
    if(sql_query.exec()){
        qDebug() << "成功建Groupinfo表！";
    }else{
        qDebug() << "Error: 创建Groupinfo表失败" << sql_query.lastError();
    }
}

void Widget::create_Table_Groupship(){
    // 创建Groupship表
    QSqlQuery sql_query;
    QString create_sql = "CREATE TABLE IF NOT EXISTS Groupship(\
                              Username VARCHAR(20),\
                              Groupname VARCHAR(20),\
                              PRIMARY KEY(Username,Groupname),\
                              FOREIGN KEY (Username) REFERENCES User(Username),\
                              FOREIGN KEY (Groupname) REFERENCES Groupinfo(Groupname)\
                              );";
    sql_query.prepare(create_sql);
    if(sql_query.exec()){
        qDebug() << "成功建Groupship表！";
    }else{
        qDebug() << "Error: 创建Groupship表失败" << sql_query.lastError();
    }
}

void Widget::create_Table_Groupmsg(){
    // 创建Groupmsg表
    QSqlQuery sql_query;
    QString create_sql = "CREATE TABLE IF NOT EXISTS Groupmsg (\
                              Sender VARCHAR(20),\
                              Receiver VARCHAR(20),\
                              Msg VARCHAR(1024),\
                              DT datetime NOT NULL,\
                              FOREIGN KEY (Sender) REFERENCES User(Username),\
                              FOREIGN KEY (Receiver) REFERENCES Groupinfo(Groupname)\
                              );";
    sql_query.prepare(create_sql);
    if(sql_query.exec()){
        qDebug() << "成功建Groupmsg表！";
    }else{
        qDebug() << "Error: 创建Groupmsg表失败" << sql_query.lastError();
    }
}

void Widget::on_button_signup_clicked()
{
    // 向User表中插入新数据
    QString Username = ui->lineEdit_Username->text();
    QString Password = ui->lineEdit_Password->text();

    QString insert_sql = QString(
        "INSERT INTO User(Username,Password) VALUES('%1','%2');"
    ).arg(Username).arg(Password);

    QSqlQuery sql_query;
    if (sql_query.exec(insert_sql)){
        QMessageBox::information(this, "注册提示", "注册成功");
    }else{
        QMessageBox::information(this, "注册提示", "注册失败");
    }

    // 注册成功与否都刷新一下model 选择User表
    model->setTable("User");
    ui->tableView->setModel(model);
    model->select();

}

void Widget::on_button_query_clicked()
{
    model->select();
}

void Widget::on_comboBox_tables_currentTextChanged(const QString &arg1)
{
    model->setTable(arg1);
    ui->tableView->setModel(model);
    on_button_query_clicked();
}

void Widget::on_button_login_clicked()
{
    QString username =  ui->lineEdit_Username->text();
    QString password =  ui->lineEdit_Password->text();

    QString select_sql = QString(
        "SELECT * FROM User WHERE Username='%1' AND Password='%2';"
    ).arg(username).arg(password);

    QSqlQuery sql_query;
    sql_query.prepare(select_sql);
    if (sql_query.exec()){
        if (sql_query.next()){
            QMessageBox::information(this, "登录提示", "登录成功");
        }else{
            QMessageBox::information(this, "登录提示", "登录失败");
        }
    }else{
        QMessageBox::information(this, "登录提示", "登录失败");
    }

}

void Widget::on_button_create_group_clicked()
{
    QString groupName = ui->lineEdit_create_group->text();

    QString insert_sql = QString(
        "INSERT INTO Groupinfo(Groupname) VALUES('%1');"
    ).arg(groupName);

    QSqlQuery sql_query;
    if (sql_query.exec(insert_sql)){
        QMessageBox::information(this, "创建群提示", "创建群成功");
    }else{
        QMessageBox::information(this, "创建群提示", "创建群失败");
    }

    // 创建群成功与否都刷新一下model 选择Groupinfo表
    model->setTable("Groupinfo");
    ui->tableView->setModel(model);
    model->select();
}

void Widget::on_button_query_group_clicked()
{
    QString groupName = ui->lineEdit_query_group->text();

    QString select_sql = QString(
        "SELECT * FROM Groupinfo WHERE Groupname='%1';"
    ).arg(groupName);

    QSqlQuery sql_query;
    sql_query.prepare(select_sql);
    if (sql_query.exec()){
        if (sql_query.next()){
            QMessageBox::information(this, "查询群提示", "查询群成功");
        }else{
            QMessageBox::information(this, "查询群提示", "查询群失败");
        }
    }else{
        QMessageBox::information(this, "查询群提示", "查询群失败");
    }    
}

void Widget::on_button_add_group_clicked()
{
    QString groupName = ui->lineEdit_add_group->text();
    QString username = ui->lineEdit_Username->text(); //当前登录的用户


    QString insert_sql = QString(
        "INSERT INTO Groupship(Username,Groupname) VALUES('%1','%2');"
    ).arg(username).arg(groupName);

    QSqlQuery sql_query;
    if (sql_query.exec(insert_sql)){
        QMessageBox::information(this, "加群提示", "加群成功");
    }else{
        QMessageBox::information(this, "加群提示", "加群失败");
    }

    // 加群成功与否都刷新一下model 选择Groupship表
    model->setTable("Groupship");
    ui->tableView->setModel(model);
    model->select();
}

void Widget::on_button_query_group_member_clicked()
{
    QString groupName = ui->lineEdit_query_group_member->text();

    QString select_sql = QString(
        "SELECT * FROM Groupship WHERE Groupname='%1';"
    ).arg(groupName);

    // 将查询结果显示在tableView上
    queryModel->setQuery(select_sql);
    ui->tableView->setModel(queryModel);

}

void Widget::on_button_send_group_clicked()
{
    QString sendGroupName = ui->lineEdit_send_group_name->text();
    QString sendGroupMessage = ui->lineEdit_send_group_message->text();
    QString username = ui->lineEdit_Username->text(); //当前登录的用户

    QString insert_sql = QString(
        "INSERT INTO Groupmsg(Sender,Receiver,Msg,DT) VALUES('%1','%2','%3',datetime('now','localtime'));"
    ).arg(username).arg(sendGroupName).arg(sendGroupMessage);

    QSqlQuery sql_query;
    if (sql_query.exec(insert_sql)){
        QMessageBox::information(this, "发送群消息提示", "发送群消息成功");
    }else{
        QMessageBox::information(this, "发送群消息提示", "发送群消息失败");
    }

    // 发送群消息成功与否都刷新一下model 选择Groupmsg表
    model->setTable("Groupmsg");
    ui->tableView->setModel(model);
    model->select();
}

void Widget::on_button_query_group_list_clicked()
{
    QString username = ui->lineEdit_Username->text(); //当前登录的用户

    QString select_sql = QString(
        "SELECT * FROM Groupship WHERE Username='%1';"
    ).arg(username);

    // 将查询结果显示在tableView上
    queryModel->setQuery(select_sql);
    ui->tableView->setModel(queryModel);
}

void Widget::on_button_query_friend_clicked()
{
    QString friendName = ui->lineEdit_query_friend->text();

    QString select_sql = QString(
        "SELECT * FROM User WHERE Username='%1';"
    ).arg(friendName);

    QSqlQuery sql_query;
    sql_query.prepare(select_sql);
    if (sql_query.exec()){
        if (sql_query.next()){
            QMessageBox::information(this, "查询好友提示", "查询好友成功");
        }else{
            QMessageBox::information(this, "查询好友提示", "查询好友失败");
        }
    }else{
        QMessageBox::information(this, "查询好友提示", "查询好友失败");
    }
}

void Widget::on_button_add_friend_clicked()
{
    QString myName = ui->lineEdit_Username->text();
    QString friendName = ui->lineEdit_query_friend->text();

    // 得添加两条记录
    QString insert_sql1 = QString(
        "INSERT INTO Friendship(Myname,Friendname) VALUES('%1','%2');"
    ).arg(myName).arg(friendName);

    QString insert_sql2 = QString(
        "INSERT INTO Friendship(Myname,Friendname) VALUES('%1','%2');"
    ).arg(friendName).arg(myName);

    QSqlQuery sql_query;
    if (sql_query.exec(insert_sql1) && sql_query.exec(insert_sql2)){
        QMessageBox::information(this, "添加好友提示", "添加好友成功");
    }else{
        QMessageBox::information(this, "添加好友提示", "添加好友失败");
    }

    // 添加好友成功与否都刷新一下model 选择Friendship表
    model->setTable("Friendship");
    ui->tableView->setModel(model);
    model->select();
    
}

void Widget::on_button_send_friend_clicked()
{
    QString sendFriendName = ui->lineEdit_send_friend_name->text();
    QString sendFriendMessage = ui->lineEdit_send_friend_message->text();
    QString username = ui->lineEdit_Username->text(); //当前登录的用户

    QString insert_sql = QString(
        "INSERT INTO Friendmsg(Sender,Receiver,Msg,DT) VALUES('%1','%2','%3',datetime('now','localtime'));"
    ).arg(username).arg(sendFriendName).arg(sendFriendMessage);

    QSqlQuery sql_query;
    if (sql_query.exec(insert_sql)){
        QMessageBox::information(this, "发送好友消息提示", "发送好友消息成功");
    }else{
        QMessageBox::information(this, "发送好友消息提示", "发送好友消息失败");
    }

    // 发送好友消息成功与否都刷新一下model 选择Friendmsg表
    model->setTable("Friendmsg");
    ui->tableView->setModel(model);
    model->select();
}

void Widget::on_button_query_friend_list_clicked()
{
    QString username = ui->lineEdit_Username->text(); //当前登录的用户

    QString select_sql = QString(
        "SELECT * FROM Friendship WHERE Myname='%1';"
    ).arg(username);

    // 将查询结果显示在tableView上
    queryModel->setQuery(select_sql);
    ui->tableView->setModel(queryModel);
}

void Widget::on_button_alter_nickname_clicked()
{
    QString nickname = ui->lineEdit_alter_nickname->text();
    QString username = ui->lineEdit_Username->text(); //当前登录的用户

    QString update_sql = QString(
        "UPDATE User SET Nickname='%1' WHERE Username='%2';"
    ).arg(nickname).arg(username);

    QSqlQuery sql_query;
    if (sql_query.exec(update_sql)){
        QMessageBox::information(this, "修改昵称提示", "修改昵称成功");
    }else{
        QMessageBox::information(this, "修改昵称提示", "修改昵称失败");
    }

    // 修改昵称成功与否都刷新一下model 选择User表
    model->setTable("User");
    ui->tableView->setModel(model);
    model->select();
}

void Widget::on_button_alter_profile_clicked()
{
    QString profile_FilePath = ui->lineEdit_alter_profile->text();
    QString username = ui->lineEdit_Username->text(); //当前登录的用户

    QString update_sql = QString(
        "UPDATE User SET Profile_picture='%1' WHERE Username='%2';"
    ).arg(profile_FilePath).arg(username);

    QSqlQuery sql_query;
    if (sql_query.exec(update_sql)){
        QMessageBox::information(this, "修改头像提示", "修改头像成功");
    }else{
        QMessageBox::information(this, "修改头像提示", "修改头像失败");
    }

    // 修改头像成功与否都刷新一下model 选择User表
    model->setTable("User");
    ui->tableView->setModel(model);
    model->select();
}
