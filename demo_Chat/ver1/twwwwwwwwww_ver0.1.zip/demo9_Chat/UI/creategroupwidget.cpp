#include "creategroupwidget.h"
#include "ui_creategroupwidget.h"

CreateGroupWidget::CreateGroupWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::CreateGroupWidget)
{
    ui->setupUi(this);
    this->setWindowFlags(Qt::FramelessWindowHint); //无窗口边框
}

CreateGroupWidget::~CreateGroupWidget()
{
    delete ui;
}

void CreateGroupWidget::on_minimizeButton_clicked()
{
    this->showMinimized();
}

void CreateGroupWidget::on_closeButton_clicked()
{
    this->close();
}

void CreateGroupWidget::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton)
    {
        m_dragStartPosition = event->globalPos() - frameGeometry().topLeft();
        event->accept();
    }
}

void CreateGroupWidget::mouseMoveEvent(QMouseEvent *event)
{
    if (event->buttons() & Qt::LeftButton)
    {
        QPoint newPos = event->globalPos() - m_dragStartPosition;
        move(newPos);
        event->accept();
    }
}

void CreateGroupWidget::on_button_createGroup_clicked()
{
    // 创建群聊 往服务器中写入数据
}
