#include "addgroupwidget.h"
#include "ui_addgroupwidget.h"

AddGroupWidget::AddGroupWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AddGroupWidget)
{
    ui->setupUi(this);
    this->setWindowFlags(Qt::FramelessWindowHint); //无窗口边框
}

AddGroupWidget::~AddGroupWidget()
{
    delete ui;
}

void AddGroupWidget::on_minimizeButton_clicked()
{
    this->showMinimized();
}

void AddGroupWidget::on_closeButton_clicked()
{
    this->close();
}

void AddGroupWidget::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton)
    {
        m_dragStartPosition = event->globalPos() - frameGeometry().topLeft();
        event->accept();
    }
}

void AddGroupWidget::mouseMoveEvent(QMouseEvent *event)
{
    if (event->buttons() & Qt::LeftButton)
    {
        QPoint newPos = event->globalPos() - m_dragStartPosition;
        move(newPos);
        event->accept();
    }
}


void AddGroupWidget::on_button_addGroup_clicked()
{
    // 添加群聊功能代码
}

void AddGroupWidget::on_button_search_clicked()
{
    // 搜索群聊存在
}
